
  export const updateScore ="UPDATE_SCORE";
  export const startGame ="STARTGAME";
  export const endGame ="endGAME";
  